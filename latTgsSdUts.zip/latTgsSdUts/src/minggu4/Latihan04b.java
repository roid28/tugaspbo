/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package minggu4;

/**
 *
 * @author D2K
 */
public class Latihan04b {
    public static void main(String[] args) {
        int a,hasil;
        a = 14;
        hasil = (a++ > 5 )? 10 : 20;
        System.out.println("Output Satu  : " + hasil);
        
        hasil = (a <= 14) ? 30 : 40;
        System.out.println("Output Dua  : " + hasil);
        
        hasil = (a < 13 && a < 45) ? 50 : 60 ;
        System.out.println("Output Tiga : " + hasil);
        
        hasil = (a < 14 || a < 45) ? 70 : 80;
        System.out.println("Output Empat : " +hasil);
        
        System.out.println("\n========================");
        System.out.println("Program  : Latihan04b");
        System.out.println("NIM      : A12.2022.06882");
        System.out.println("Nama     : Slamet Ikhvan Nurhana Rifki");
        
        
    }
}
