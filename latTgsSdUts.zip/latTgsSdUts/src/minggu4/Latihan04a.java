/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package minggu4;

/**
 *
 * @author D2K
 */
public class Latihan04a {
    public static void main(String[] args) {
        int x=5;
        System.out.println("x       = " + x);
        System.out.println("x + = 1 = " + (x += 1));
        System.out.println("x -= 2 = " + (x -= 2));
        System.out.println("x *= 3 = " + (x *= 3));
        System.out.println("x /= 4 = " + (x /= 4));
        System.out.println("x %= 5 = " + (x %= 5));
        
        System.out.println("\n======================");
        System.out.println("Program     : Latihan03a");
        System.out.println("NIM         : A12.2022.06882");
        System.out.println("Nama        : Slamet Ikhvan Nurhana Rifki");
        
        
        
        
        
    }
}
