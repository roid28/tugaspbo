/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package minggu4;

/**
 *
 * @author D2K
 */
public class Latihan04e {
    public static void main(String[] args) {
        int a = 8;
        int b = 20;
        
        System.out.println("Nilai a      : " + (a));
        System.out.println("Nilai b      : " + (b));
        System.out.println("Nilai a>>1      : " + (a >> 1));
        System.out.println("Nilai a>>2      : " + (a >> 2));
        System.out.println("Nilai b<<1      : " + (b << 1));
        System.out.println("Nilai b<<2      : " + (b << 2));
        
        System.out.println("\n========================");
        System.out.println("Program  : Latihan04e");
        System.out.println("NIM      : A12.2022.06882");
        System.out.println("Nama     : Slamet Ikhvan Nurhana Rifki");
        
    }
}
