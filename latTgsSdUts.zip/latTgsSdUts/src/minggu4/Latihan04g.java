/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package minggu4;

/**
 *
 * @author D2K
 */
public class Latihan04g {
    public static void main(String[] args) {
        int x1, x2, x3,x4,x5;
        
        x1 = 5 + 7 * 2;
        x2 = (5 + 7) * 2 -1;
        x3 = 5 + 7 * 2 -1;
        x4 = (5+7) * (2-1);
        x5 = 1 + 2 -3 * 4 % 5;
        
        System.out.println("5 + 7 * 2         :"  + (x1));
        System.out.println("(5 + 7) * 2         :"  + (x2));
        System.out.println("5 + 7 * 2- 1         :"  + (x3));
        System.out.println("5 + 7) * (2 -1)         :"  + (x3));
    }
}
