/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package minggu4;

/**
 *
 * @author D2K
 */
public class Latihan04c {
    public static void main(String[] args) {
        int x = 9;
        int y = 3;
        
        System.out.println("1. " + (x > 3 && x < 10));
        System.out.println("2. " + (x > 3 && y > 10));
        System.out.println("3. " + (x < 3 || y < 10));
        System.out.println("4. " + (x < 3 || y > 10));
        System.out.println("5. " + (x++ > 9 && y+1 > 4));
        System.out.println("6. " + (x > 9 && y+1 > 4));
        System.out.println("7. " + (x++ > 9 || y+1 == 4));
        System.out.println("8. " + (x > 9 || y+1 == 4));
        
        System.out.println("\n========================");
        System.out.println("Program  : Latihan04c");
        System.out.println("NIM      : A12.2022.06882");
        System.out.println("Nama     : Slamet Ikhvan Nurhana Rifki");
        
        
    }
}
