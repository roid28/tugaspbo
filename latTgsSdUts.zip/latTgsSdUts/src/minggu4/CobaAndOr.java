/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package minggu4;

/**
 *
 * @author D2K
 */
public class CobaAndOr {
    public static void main(String[] args) {
        int a = 17;
        int b = 8;
        int c = 5;
        
        System.out.println("a & b = " + (a & b ));
        System.out.println("a | b = " + (a | c ));
    }
}
