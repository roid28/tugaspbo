/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package minggu4;

/**
 *
 * @author D2K
 */
public class Latihan04f {
    public static void main(String[] args) {
        int a = 8;
        int b = 10;
        
        System.out.println("Nilai a      : " + (a));
        System.out.println("Nilai b      : " + (b));
        System.out.println("a++          : " + (a++));
        System.out.println("++a          : " + (++a));
        System.out.println("a++ + ++a      : " + (a++ + b++));
        System.out.println("b++ + b++      : " + (b++ + b++));
        
    }
}
