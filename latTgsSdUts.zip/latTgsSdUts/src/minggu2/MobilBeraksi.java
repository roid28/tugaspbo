/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package minggu2;


public class MobilBeraksi {
    public static void main(String[]args){
    //Membuat object
    Mobil mobilku= new Mobil();
    
    /*memanggil atribut dan memberi nilai*/
    mobilku.warna="Hitam";
    mobilku.tahunProduksi=2006;
    System.out.println("Warna:" + mobilku.warna);
    System.out.println("Tahun:" + mobilku.tahunProduksi);
    }
}
