/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package minggu2;

/**
 *
 * @author D2K
 */
public class Mobil2Beraksi {
    public static void main(String[]args){
    Mobil2 mobilku=new Mobil2();
    
    mobilku.warna="Hitam";
    mobilku.tahunProduksi=2006;
    mobilku.printMobil();
    }
}
