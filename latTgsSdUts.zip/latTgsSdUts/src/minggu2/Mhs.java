/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package minggu2;

/**
 *
 * @author D2K
 */
public class Mhs {
    //property...............
    private String nama;
    private float ipk;
    
    //behavior...........
    public void setNama(String nama)
    {
        this.nama=nama;
       
    }
    public void setIpk(int ipk)
    {
        this.ipk = ipk;
    }
    public String getNama()
    {
        return this.nama;
    }
}
