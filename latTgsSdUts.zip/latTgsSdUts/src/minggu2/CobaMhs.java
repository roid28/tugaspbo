/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package minggu2;

/**
 *
 * @author D2K
 */
public class CobaMhs {
    public static void main(String[]args)
    {
        Mhs mhsAdi = new Mhs();
        mhsAdi.setNama("Adi Sanjaya");
        System.out.print("Nama Mhs : " + mhsAdi.getNama());
    }
}
