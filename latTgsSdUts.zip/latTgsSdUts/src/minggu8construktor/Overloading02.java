/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package minggu8construktor;

/**
 *
 * @author D2K
 */
class Overloading02 {
    String nama;
    int ccmobil;

    Overloading02(String nama) {
        this.nama=nama;
    }

    Overloading02(String nama,int ccmobil) {
        this.nama=nama;
        this.ccmobil=ccmobil;
    }
    
    
    
}
class CobaMobil{
    public static void main(String[] args) {
        Overloading02 mobilA = new Overloading02("Agya");
        Overloading02 mobilB = new Overloading02("Katana",1500);
        System.out.println("Mobil LCGC   : "+ mobilA.nama);
        System.out.println("Mobil" +mobilB.nama);
        
    }
}