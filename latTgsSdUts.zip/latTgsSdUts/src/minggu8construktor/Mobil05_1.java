/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package minggu8construktor;

/**
 *
 * @author D2K
 */
class Mobil05_1 {
   String nama;
   Mobil05_1 (){}
   Mobil05_1(String nama)
   {
   this.nama=nama;
   }
   public void setnama(String nama)
   {
       this.nama=nama;
   }
}
   class CobaMobil
   {
       public static void main(String[] args) {
           Mobil05_1 mobilx = new Mobil05_1();
           Mobil05_1 mobilLCGC = new Mobil05_1("Agya");
           System.out.println("Mobil LCGC   :  " +mobilLCGC.nama);
           mobilx.setnama("Wuling");
           System.out.println("Mobil      :  " +mobilx.nama);
       }
   }
