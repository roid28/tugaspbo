/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package minggu5;

import java.util.Scanner;

/**
 *
 * @author D2K
 */
public class Latihan05b {
    public static void main(String[] args) {
        
        int tanak;
        int total;
        
        Scanner input = new Scanner(System.in);
        
        System.out.println("Nama: ");
        String nama = input.nextLine();
        
        System.out.println("Jumlah anak");
        int anak = input.nextInt();
        
        System.out.println("Gaji pokok: ");
        int gaji = input.nextInt();
        
        
        
        if (anak > 3)
            tanak = 3 * 200000;
        else 
            tanak = anak * 200000;
        
        total = gaji + tanak;
        
        System.out.println("\n Hitung Tunj. anak");
        System.out.println("============================");
        System.out.println("Nama : " + nama);
        System.out.println("Anak : " + anak);
        System.out.println("Gaji : " + gaji);
        System.out.println("Tunj anak : " + tanak);
        System.out.println("Total : " + total);
        
    }
}
