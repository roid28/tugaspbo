/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package minggu3;

/**
 *
 * @author D2K
 */
public class Latihan03d {
    public static void main(String[] args){
    int panjang,lebar, luas;
    
    panjang = 10;
    lebar = 15;
    
    luas = panjang * lebar;
    System.out.println("Luas =  " + luas  );
    }
}
