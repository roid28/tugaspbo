/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package minggu3;

/**
 *
 * @author D2K
 */
public class latihan03a {
    public static void main(String[] args){
        System.out.print("Sistem");
        System.out.println("Informasi");
        System.out.println("Udinus");
    }
}
