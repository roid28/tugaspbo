/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package minggu3;

/**
 *
 * @author D2K
 */
public class Latihan03c {
    public static void main(String[] args){
    String angka = "1010";
    int angka2 = Integer.valueOf(angka);
    
    System.out.println(angka + 10);
    System.out.println(angka2 + 10);
    }
}
