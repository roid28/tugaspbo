/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package minggu3;

/**
 *
 * @author D2K
 */
public class Latihan03i {
    public static void main(String[] args){
    String string1 ="123";
    String string2 = "123";
    
    int varstr1 = Integer.parseInt(string1);
    
    System.out.println(varstr1 + 2);
    System.out.println(string1 + varstr1);
    
    int varstr2 = Integer.parseInt(string2);
    System.out.println(varstr2);
    }
}
