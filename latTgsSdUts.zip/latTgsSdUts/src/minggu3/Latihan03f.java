/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package minggu3;

/**
 *
 * @author D2K
 */
public class Latihan03f {
    public static void main(String[] args){
    int[] myList = {1, 2, 3, 4, 5};
    
    for (int i = 0; i < myList.length; i++){
        System.out.println(myList[i]);
    }
    }
}
