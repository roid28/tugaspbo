/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package minggu3;

import java.util.Scanner;

/**
 *
 * @author D2K
 */
public class Latihan03j {
    
    public static void main(String[] args){
    Scanner u_input = new Scanner(System.in);
    
    String nama;
    int nilai1, nilai2;
    float rata2;
    
    System.out.print("Nama : ");
    nama = u_input.next();
    System.out.print("Nilai1 : ");
    nilai1 = u_input.nextInt();
    System.out.print("Nilai2 : ");
    nilai2 = u_input.nextInt();
    System.out.print("=============");
    rata2 = (nilai1 + nilai2) /2;
    System.out.print("Nama : " + nama);
    System.out.print("Rata2 : " + rata2);
    System.out.print("Nilai1 : " + nilai1);
    
 
    }
}
